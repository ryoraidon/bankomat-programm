import pymysql
import eel
import random

connection = pymysql.connect(host="localhost", port=3306, user="root", passwd="79370378722pd", database="python")
cursor = connection.cursor()
eel.init(".");


@eel.expose
def add_ccn(ccn, pincode):
    cursor.execute('INSERT into `card`(ccn,pincode,balance) VALUES(%s,%s,%s)', (ccn, pincode, 0))
    connection.commit();


@eel.expose
def get_balan(ccn):
    cursor.execute('SELECT balance FROM `card` WHERE ccn=%s', (ccn));
    return cursor.fetchall()


@eel.expose
def auth(ccn, pincode):
    cursor.execute('SELECT ccn FROM `card` WHERE ccn=%s and pincode=%s', (ccn, pincode));

    return cursor.fetchall()[0][0]


@eel.expose
def withdraw(withdraw, ccn):
    balance = get_balan(ccn)[0][0];
    if (balance < withdraw):
        return 0;

    balance = balance - withdraw
    result = cursor.execute('UPDATE `card` SET balance=%s WHERE ccn = %s', (balance, ccn))
    connection.commit();


@eel.expose
def deposit(dep, ccn):
    balance = get_balan(ccn)[0][0];
    balance = balance + dep
    result = cursor.execute('UPDATE `card` SET balance=%s WHERE ccn = %s', (balance, ccn))
    connection.commit();


@eel.expose
def generate_ccn():
    while 1:
        result = -1;
        num = 0
        number = [];

        while num < 16:
            number.append(random.randint(0, 9));
            num = num + 1;

        sum_num = [];
        for i, x in enumerate(number):
            if i % 2 != 1:
                if x * 2 > 9:
                    sum_num.append(x - 9);
                else:
                    sum_num.append(x);
        else:
            sum_num.append(x);
        for x in sum_num:
            result += x;

        if (result % 10 == 0):
            return number;


eel.start("/web.html", size=(600, 800))