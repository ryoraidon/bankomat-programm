
import eel
import random
import sqlite3
from functools import reduce


connection = sqlite3.connect("test.db");
cursor = connection.cursor();
#cursor.execute("CREATE TABLE card( id int PRIMARY KEY, pincode int, balance int, ccn varchar(20))")
#connection.commit();
eel.init(".");
@eel.expose
def add_ccn(ccn,pincode):
    cursor.execute('INSERT into `card`(ccn,pincode,balance) VALUES(?,?,?)',(ccn,pincode,0))
    connection.commit();

@eel.expose
def get_balan(ccn):
    cursor.execute('SELECT balance FROM `card` WHERE ccn=?',(ccn,));
    return cursor.fetchall()
@eel.expose
def auth(ccn,pincode):
    cursor.execute('SELECT ccn FROM `card` WHERE ccn=? and pincode=?',(ccn,pincode,));
    
    return cursor.fetchall()[0][0]

    
@eel.expose
def withdraw(withdraw,ccn):
    balance = get_balan(ccn)[0][0];
    if(balance<withdraw):
        return 0;
        
    balance = balance-withdraw
    cursor.execute('UPDATE `card` SET balance=? WHERE ccn = ?',(balance,ccn,))
    connection.commit();
@eel.expose
def deposit(dep,ccn):
    balance = get_balan(ccn)[0][0];
    balance = balance+dep
    cursor.execute('UPDATE `card` SET balance=? WHERE ccn = ?',(balance,ccn,))
    connection.commit();

   


@eel.expose
def generate_ccn():
    temp = False
    while temp !=True:
        num = generate_num()
        temp = luhn(num)
    return num;
    
def generate_num():
          num = 0
          string = ""
   
          while num<16:
              string = string+(str(random.randint(0,9)));
             
              num=num+1;
          return string;

def luhn(code):
    LOOKUP = (0, 2, 4, 6, 8, 1, 3, 5, 7, 9)
    code = reduce(str.__add__, filter(str.isdigit, code))
    evens = sum(int(i) for i in code[-1::-2])
    odds = sum(LOOKUP[int(i)] for i in code[-2::-2])
    return ((evens + odds) % 10 == 0)

eel.start("web.html", size = (600,800))


